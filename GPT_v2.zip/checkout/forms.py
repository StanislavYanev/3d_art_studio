from django import forms
from .models import Order


class OrderCreateForm(forms.ModelForm):
    accept_terms = forms.BooleanField(
        label='Съгласен съм с <a href="/terms/" target="_blank" class="underline text-indigo-600">Общите условия</a>',
        required=True
    )

    class Meta:
        model = Order
        fields = [
            "first_name",
            "last_name",
            "email",
            "phone_number",
            "address",
            "city",
            "courier",
            "delivery_type",
            "delivery_details",
            "comment",
        ]
        labels = {
            "first_name": "Име",
            "last_name": "Фамилия",
            "email": "Имейл",
            "phone_number": "Телефонен номер",
            "address": "Адрес",
            "city": "Град",
            "courier": "Куриер",
            "delivery_type": "Тип доставка",
            "delivery_details": "Офис или адрес",
            "comment": "Бележки",
        }

    def clean_accept_terms(self):
        accepted = self.cleaned_data.get("accept_terms")
        if not accepted:
            raise forms.ValidationError("Моля, приемете Общите условия, за да продължите.")
        return accepted