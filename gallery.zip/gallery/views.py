import random
from django.views.generic import ListView
from .models import GalleryImage


class GalleryView(ListView):
    model = GalleryImage
    template_name = "gallery/gallery.html"
    context_object_name = "images"
    paginate_by = 9  # или 12, ако искаш по-плътно

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        layout_classes = [
            "col-span-2 row-span-2",
            "col-span-2",
            "row-span-2",
            "col-span-1",
            "", "", "", "",  # обикновени блокове
        ]

        images = list(context["images"])
        random.shuffle(images)
        random.shuffle(layout_classes)

        # Запълваме всички слотове, повтаряйки класовете ако трябва
        styled_images = [
            {"image": img, "class": layout_classes[i % len(layout_classes)]}
            for i, img in enumerate(images)
        ]

        context["images"] = styled_images
        return context
